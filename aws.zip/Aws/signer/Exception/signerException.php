<?php
namespace Aws\signer\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **AWS Signer** service.
 */
class signerException extends AwsException {}
